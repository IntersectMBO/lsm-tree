0.2.1
---

- Fix build on aarch64.



0.2.0
---

- Fix MacOS, Windows Build
