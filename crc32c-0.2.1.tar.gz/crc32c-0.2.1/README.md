# crc32c [![Hackage](https://img.shields.io/hackage/v/crc32c.svg)](https://hackage.haskell.org/package/crc32c) [![Build Status](https://travis-ci.org/leptonyu/crc32c.svg?branch=master)](https://travis-ci.org/leptonyu/crc32c)
Haskell bindings for [crc32c](https://github.com/google/crc32c)

